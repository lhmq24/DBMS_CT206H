/*
 * Copyright (c) 2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.beans.Encoder;
import java.beans.Expression;
import java.beans.Introspector;
import java.beans.Statement;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import com.jformdesigner.model.FormObject;

/**
 * @author Karl Tauber
 * @since 5.1
 */
public class JFDMLEncoder
	extends Encoder
	implements AutoCloseable
{
	private final Writer out;
	private final String charset;
	private final CharsetEncoder encoder;

	private final Map<Object, ValueData> valueToExpressionMap = new IdentityHashMap<>();
	private final Map<Object, List<Statement>> targetToStatementListMap = new IdentityHashMap<>();

	private final Map<Object, String> valueToIDMap = new IdentityHashMap<>();
	private final Map<String, Integer> classNameToCountMap = new HashMap<>();

	private Object owner;
	private JFDMLClassNameMapper classNameMapper;
	private boolean headerWritten;
	private boolean internal;
	private int indent;
	private char[] indentChars;

	public JFDMLEncoder( OutputStream out ) {
		this( out, null );
	}

	public JFDMLEncoder( OutputStream out, String charset ) {
		this.charset = (charset != null) ? charset : "UTF-8";
		this.encoder = Charset.forName( this.charset ).newEncoder();
		this.out = new BufferedWriter( new OutputStreamWriter( out, encoder ) );
	}

	public Object getOwner() {
		return owner;
	}

	public void setOwner( Object owner ) {
		this.owner = owner;
		writeExpression( new Expression( this, "getOwner", new Object[0] ) );
	}

	public JFDMLClassNameMapper getClassNameMapper() {
		return classNameMapper;
	}

	public void setClassNameMapper( JFDMLClassNameMapper classNameMapper ) {
		this.classNameMapper = classNameMapper;
	}

	@Override
	public Object get( Object oldInstance ) {
		if( isStringOrPrimitive( oldInstance ) )
			return oldInstance;

		return super.get( oldInstance );
	}

	public void writeHeader( Map<String, String> headerAttributes ) {
		if( headerWritten )
			throw new IllegalStateException( "Header already written" );

		write( "JFDML" );
		if( headerAttributes != null ) {
			for( Map.Entry<String, String> entry : headerAttributes.entrySet() ) {
				String value = entry.getValue();
				if( value == null )
					continue;

				write( ' ' );
				write( entry.getKey() );
				write( ": " );
				outputString( value, '"' );
			}
		}
		write( " encoding: " );
		outputString( charset, '"' );
		write( "\n\n" );

		headerWritten = true;
	}

	public void writeComment( String comment ) {
		if( comment == null )
			return;

		if( !headerWritten )
			writeHeader( null );

		write( "/*\n" );
		write( comment );
		write( "\n*/\n\n" );
	}

	@Override
	public void writeObject( Object obj ) {
		if( internal )
			super.writeObject( obj );
		else
			writeStatement( new Statement( this, "writeObject", new Object[] { obj } ) );
	}

	@Override
	public void writeStatement( Statement oldStm ) {
		boolean oldInternal = internal;
		internal = true;
		try {
			super.writeStatement( oldStm );

			mark( oldStm );

			Object target = oldStm.getTarget();
			if( target instanceof Field ) {
				String method = oldStm.getMethodName();
				Object[] args = oldStm.getArguments();
				if( method != null && args != null &&
					((method.equals( "get" ) && args.length == 1) ||
					 (method.equals( "set" ) && args.length == 2)) )
				  target = args[0];
			}
			getStatementList( target ).add( oldStm );

		} catch( Exception ex ) {
			getExceptionListener().exceptionThrown( new Exception( "JFDMLEncoder: discarding statement " + oldStm, ex ) );
		} finally {
			internal = oldInternal;
		}
	}

	@Override
	public void writeExpression( Expression oldExpr ) {
		boolean oldInternal = internal;
		internal = true;
		try {
			Object oldValue = getExpressionValue( oldExpr );
			if( get( oldValue ) == null || (isStringOrPrimitive( oldValue ) && !internal) ) {
				getValueData( oldValue ).expr = oldExpr;
				super.writeExpression( oldExpr );
			}
		} finally {
			internal = oldInternal;
		}
	}

	private Object getExpressionValue( Expression expr ) {
		try {
			return (expr != null) ? expr.getValue() : null;
		} catch( Exception ex ) {
			getExceptionListener().exceptionThrown( ex );
			throw new RuntimeException( "Failed to evaluate: " + expr.toString() );
		}
	}

	private List<Statement> getStatementList( Object target ) {
		return targetToStatementListMap.computeIfAbsent( target, k -> new ArrayList<>() );
	}

	private ValueData getValueData( Object obj ) {
		return valueToExpressionMap.computeIfAbsent( obj, k -> new ValueData() );
	}

	private void mark( Statement statement ) {
		Object[] args = statement.getArguments();
		for( Object arg : args )
			mark( arg, true );

		mark( statement.getTarget(), false );
	}

	private void mark( Object obj, boolean isArgument ) {
		if( obj == null || obj == this )
			return;

		ValueData valueData = getValueData( obj );
		Expression expr = valueData.expr;

		if( isStringOrPrimitive( obj ) && expr == null )
			return;

		if( isArgument )
			valueData.refCount++;

		if( valueData.marked )
			return;

		valueData.marked = true;
		mark( expr );

		Object target = expr.getTarget();
		if( !(target instanceof Class) ) {
			getStatementList( target ).add( expr );
			valueData.refCount++;
		}
	}

	@Override
	public void close() {
		flush();

		try {
			out.close();
		} catch( IOException ex ) {
			getExceptionListener().exceptionThrown( ex );
		}
	}

	public void flush() {
		if( !headerWritten )
			writeHeader( null );

		List<Statement> statements = getStatementList( this );
		while( !statements.isEmpty() ) {
			Statement statement = statements.remove( 0 );
			if( "writeObject".equals( statement.getMethodName() ) )
				outputValue( statement.getArguments()[0], this, false );
			else
				outputStatement( statement, this, true );
			write( '\n' );
		}

		Statement statement = getMissedStatement();
		while( statement != null ) {
			outputStatement( statement, this, false );
			statement = getMissedStatement();
		}

		try {
			out.flush();
		} catch( IOException ex ) {
			getExceptionListener().exceptionThrown( ex );
		}

		valueToExpressionMap.clear();
		targetToStatementListMap.clear();
		valueToIDMap.clear();
		classNameToCountMap.clear();
	}

	Statement getMissedStatement() {
		for( List<Statement> statements : this.targetToStatementListMap.values() ) {
			for( int i = 0; i < statements.size(); i++ ) {
				if( Statement.class == statements.get( i ).getClass() )
					return statements.remove( i );
			}
		}
		return null;
	}

	private void outputStatement( Statement expr, Object outer, boolean isVoid ) {
		Object target = expr.getTarget();
		String methodName = expr.getMethodName();
		if( target == null )
			throw new NullPointerException( "target should not be null" );
		if( methodName == null )
			throw new NullPointerException( "methodName should not be null" );

		Object[] args = expr.getArguments();
		boolean isExpression = (expr instanceof Expression);
		Object value = isExpression ? getExpressionValue( (Expression) expr ) : null;
		ValueData valueData = getValueData( value );
		String className = null;

		if( target != outer ) {
			if( target == Array.class && methodName.equals( "newInstance" ) ) {
				// reference anchor
				if( isExpression && valueData.refCount > 1 ) {
					valueData.id = idForValue( value );
					write( '&' );
					write( valueData.id );
					write( ' ' );
				}

				// array
				Class<?> componentType = (Class<?>) args[0];
				outputArray( componentType, value );
				return;

			} else if( target.getClass() == Class.class ) {
				className = ((Class<?>)target).getName();
				if( classNameMapper != null )
					className = classNameMapper.encode( className );
			} else {
				valueData.refCount = 2;
				if( valueData.id == null ) {
					getValueData( target ).refCount++;

					List<Statement> statements = getStatementList( target );
					if( !statements.contains( expr ) )
						statements.add( expr );

					outputValue( target, outer, true );
				}
				if( isExpression ) {
					write( '\n' );
					writeIndent();
					outputValue( value, outer, isVoid );
				}
				return;
			}
		}

		if( !isExpression && className == null &&
			target instanceof FormObject && methodName.equals( "setProperty" ) &&
			args.length == 2 && args[0] instanceof String )
		{
			// invoke obj.setProperty( name, value )
			outputString( (String) args[0], '"' );
			write( ": " );
			outputValue( args[1], null, false );

		} else if( !isExpression && className == null &&
			methodName.startsWith( "set" ) &&
			methodName.length() > 3 && args.length == 1 )
		{
			// invoke property setter
			write( Introspector.decapitalize( methodName.substring( 3 ) ) );
			write( ": " );
			outputValue( args[0], null, false );

		} else {
			if( isVoid )
				write( "void " );

			// reference anchor
			if( isExpression && valueData.refCount > 1 ) {
				valueData.id = idForValue( value );
				write( '&' );
				write( valueData.id );
				write( ' ' );
			}

			if( className != null ) {
				if( methodName.equals( "new" ) ) {
					// invoke constructor
					write( "new " );
					write( className );
				} else {
					// invoke static method
					write( "static " );
					write( className );
					write( ' ' );
					write( methodName );
				}
			} else {
				// invoke (non-static) method
				write( methodName );
			}

			// method parameters
			if( args.length > 0 ) {
				write( "( " );
				for( int i = 0; i < args.length; i++ ) {
					if( i > 0 )
						write( ", " );
					outputValue( args[i], null, false );
				}
				write( " )" );
			} else if( !methodName.equals( "new" ) )
				write( "()" );
		}

		outputValueStatements( value );
	}

	private void outputValueStatements( Object value ) {
		// statements operating on return value of expression
		List<Statement> statements = getStatementList( value );
		if( !statements.isEmpty() ) {
			write( " {\n" );
			indent++;
			while( !statements.isEmpty() ) {
				writeIndent();
				Statement statement = statements.remove( 0 );
				outputStatement( statement, value, false );
				write( '\n' );
			}
			indent--;
			writeIndent();
			write( '}' );
		}
	}

	/**
	 * @since 7.0.1
	 */
	private void outputArrayClass( Class<?> cls ) {
		int dimensions = 0;
		while( cls.isArray() ) {
			cls = cls.getComponentType();
			dimensions++;
		}

		write( cls.getName() );
		for( int i = 0; i < dimensions; i++ )
			write( "[]" );
	}

	private void outputArray( Class<?> componentType, Object value ) {
		int dimensions = 1;
		while( componentType.isArray() ) {
			componentType = componentType.getComponentType();
			dimensions++;
		}

		write( "new " );
		write( componentType.getName() );
		for( int i = 1; i < dimensions; i++ )
			write( '[' );
		outputArrayValues( value );
		for( int i = 1; i < dimensions; i++ )
			write( ']' );
	}

	private void outputArrayValues( Object value ) {
		int length = Array.getLength( value );
		if( length == 0 ) {
			write( "[]" );
			return;
		}

		List<Statement> statements = getStatementList( value );
		write( "[ " );
		int i = 0;
		while( !statements.isEmpty() ) {
			Statement statement = statements.remove( 0 );

			Object[] args = statement.getArguments();
			int index = ((Integer)args[0]).intValue();
			Object valueAtIndex = args[1];

			for( ; i < index; i++ ) {
				if( i > 0 )
					write( ", " );
				outputPrimitiveValue( Array.get( value, i ) );
			}

			if( i > 0 )
				write( ", " );
			outputValue( valueAtIndex, null, false );
			i++;
		}

		for( ; i < length; i++ ) {
			if( i > 0 )
				write( ", " );
			outputPrimitiveValue( Array.get( value, i ) );
		}

		write( " ]" );
	}

	private void outputValue( Object value, Object outer, boolean isVoid ) {
		if( value == null ) {
			write( "null" );
			return;
		}

		if( value instanceof Class ) {
			write( "class " );
			Class<?> cls = (Class<?>) value;
			if( cls.isArray() )
				outputArrayClass( cls );
			else
				write( cls.getName() );
			return;
		}

		ValueData valueData = getValueData( value );
		if( valueData.expr != null ) {
			Object target = valueData.expr.getTarget();
			String methodName = valueData.expr.getMethodName();
			Object[] args = valueData.expr.getArguments();
			if( target == null )
				throw new NullPointerException( "target should not be null" );
			if( methodName == null )
				throw new NullPointerException( "methodName should not be null" );

			if( target == Enum.class && methodName.equals( "valueOf" ) && args.length == 2 ) {
				write( "enum " );
				write( ((Class<?>)args[0]).getName() );
				write( ' ' );
				write( (String) args[1] );
				return;
			}

			if( !isVoid && target instanceof Field && methodName.equals( "get" ) ) {
				Field field = (Field) target;
				write( "sfield " );
				write( field.getDeclaringClass().getName() );
				write( ' ' );
				write( field.getName() );
				return;
			}

			if( isPrimitiveType( value.getClass() ) && target == value.getClass() && methodName.equals( "new" ) ) {
				outputPrimitiveValue( value );
				return;
			}
		} else if( value instanceof String ) {
			outputString( (String) value, '"' );
			return;
		} else if( isPrimitiveType( value.getClass() ) ) {
			outputPrimitiveValue( value );
			return;
		}

		if( valueData.id != null ) {
			if( isVoid )
				write( "void " );
			write( '#' );
			write( valueData.id );

			if( isVoid )
				outputValueStatements( value );
		} else if( valueData.expr != null )
			outputStatement( valueData.expr, outer, isVoid );
	}

	private void outputPrimitiveValue( Object value ) {
		if( value == null ) {
			write( "null" );
			return;
		}

		String str = value.toString();
		Class<?> valueType = value.getClass();

		if( valueType == Character.class )
			outputString( str, '\'' );
		else {
			write( str );

			if( valueType == Byte.class )
				write( 'b' );
			else if( valueType == Short.class )
				write( 's' );
			else if( valueType == Long.class )
				write( 'l' );
			else if( valueType == Float.class )
				write( 'f' );
		}
	}

	private void outputString( String str, char quote ) {
		write( quote );

		char[] chars = str.toCharArray();
		for( char ch : chars ) {
			switch( ch ) {
				case '\b': write( "\\b" ); break;
				case '\t': write( "\\t" ); break;
				case '\n': write( "\\n" ); break;
				case '\f': write( "\\f" ); break;
				case '\r': write( "\\r" ); break;
				case '\\': write( "\\\\" ); break;
				default:
					if( ch == quote ) {
						write( '\\' );
						write( quote );
					} else if( ch >= 0x20 && encoder.canEncode( ch ) )
						write( ch );
					else {
						write( "\\u" );
						String hex = Integer.toHexString( ch );
						for( int j = 4 - hex.length(); j > 0; j-- )
							write( '0' );
						write( hex );
					}
					break;
			}
		}

		write( quote );
	}

	private static boolean isStringOrPrimitive( Object value ) {
		if( value == null )
			return false;

		Class<?> cls = value.getClass();
		return cls == String.class || isPrimitiveType( cls );
	}

	private static boolean isPrimitiveType( Class<?> cls ) {
		return cls == Boolean.class ||
			   cls == Byte.class ||
			   cls == Character.class ||
			   cls == Double.class ||
			   cls == Float.class ||
			   cls == Integer.class ||
			   cls == Long.class ||
			   cls == Short.class ||
			   cls == Void.class;
	}

	void write( String str ) {
		try {
			out.write( str );
		} catch( IOException ex ) {
			getExceptionListener().exceptionThrown( ex );
		}
	}

	private void write( char ch ) {
		try {
			out.write( ch );
		} catch( IOException ex ) {
			getExceptionListener().exceptionThrown( ex );
		}
	}

	private void writeIndent() {
		if( indentChars == null || indent > indentChars.length ) {
			indentChars = new char[indent + 10];
			Arrays.fill( indentChars, '\t' );
		}

		try {
			out.write( indentChars, 0, indent );
		} catch( IOException ex ) {
			getExceptionListener().exceptionThrown( ex );
		}
	}

	private String idForValue( Object value ) {
		if( value == null )
			return "null";

		if( value instanceof Class )
			return unqualifiedClassName( (Class<?>) value );

		String id = valueToIDMap.get( value );
		if( id != null )
			return id;

		String className = unqualifiedClassName( value.getClass() );
		Object countObj = classNameToCountMap.get( className );
		int count = (countObj != null) ? ((Integer)countObj).intValue() : -1;
		count++;
		classNameToCountMap.put( className, count );

		id = className + count;
		valueToIDMap.put( value, id );
		return id;
	}

	private static String unqualifiedClassName( Class<?> cls ) {
		if( cls.isArray() )
			return unqualifiedClassName( cls.getComponentType() ).concat( "Array" );
		String className = cls.getName();
		return className.substring( className.lastIndexOf( '.' ) + 1 );
	}

	//---- class ValueData ----------------------------------------------------

	private static class ValueData {
		public Expression expr;
        public int refCount;
        public String id;
        public boolean marked;
	}
}
