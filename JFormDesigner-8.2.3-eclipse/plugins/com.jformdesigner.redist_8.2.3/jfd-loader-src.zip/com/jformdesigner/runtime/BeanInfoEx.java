/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.awt.Image;
import java.beans.*;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Karl Tauber
 */
public class BeanInfoEx
	implements BeanInfo
{
	private static final HashMap<String, PropertyDescriptor> EMPTY_MAP = new HashMap<>( 1 );
	private static final HashMap<Class<?>, PersistenceDelegate> EMPTY_MAP2 = new HashMap<>( 1 );

	private final BeanInfo beanInfo;
	private HashMap<String, PropertyDescriptor> propertiesMap;
	private HashMap<Class<?>, PersistenceDelegate> propertyPersistenceDelegatesMap;

	public BeanInfoEx( BeanInfo beanInfo ) {
		this.beanInfo = beanInfo;
	}

	@Override
	public BeanDescriptor getBeanDescriptor() {
		return beanInfo.getBeanDescriptor();
	}

	@Override
	public EventSetDescriptor[] getEventSetDescriptors() {
		return beanInfo.getEventSetDescriptors();
	}

	@Override
	public int getDefaultEventIndex() {
		return beanInfo.getDefaultEventIndex();
	}

	@Override
	public PropertyDescriptor[] getPropertyDescriptors() {
		return beanInfo.getPropertyDescriptors();
	}

	@Override
	public int getDefaultPropertyIndex() {
		return beanInfo.getDefaultPropertyIndex();
	}

	@Override
	public MethodDescriptor[] getMethodDescriptors() {
		return beanInfo.getMethodDescriptors();
	}

	@Override
	public BeanInfo[] getAdditionalBeanInfo() {
		return beanInfo.getAdditionalBeanInfo();
	}

	@Override
	public Image getIcon( int iconKind ) {
		return beanInfo.getIcon( iconKind );
	}

	public PropertyDescriptor getPropertyDescriptor( String name ) {
		if( propertiesMap == null ) {
			PropertyDescriptor[] descs = getPropertyDescriptors();
			if( descs != null && descs.length > 0 ) {
				propertiesMap = new HashMap<>( descs.length );
				for( PropertyDescriptor desc : descs )
					propertiesMap.put( desc.getName(), desc );
			} else
				propertiesMap = EMPTY_MAP;
		}
		return propertiesMap.get( name );
	}

	public EventSetDescriptor getEventSetDescriptor( String listener ) {
		EventSetDescriptor[] descs = getEventSetDescriptors();
		if( descs == null )
			return null;
		for( EventSetDescriptor desc : descs ) {
			if( listener.equals( desc.getListenerType().getName() ) )
				return desc;
		}
		return null;
	}

	public Map<Class<?>, PersistenceDelegate> getPersistenceDelegateMap() {
		if( propertyPersistenceDelegatesMap == null ) {
			PropertyDescriptor[] descs = getPropertyDescriptors();
			if( descs != null && descs.length > 0 ) {
				for( PropertyDescriptor desc : descs ) {
					Class<?> type = desc.getPropertyType();
					if( type == null )
						continue;
					Object delegate = desc.getValue( "persistenceDelegate" );
					Object extraDelegates = desc.getValue( "extraPersistenceDelegates" );
					if( delegate == null && extraDelegates == null )
						continue;

					// create map lazy
					if( propertyPersistenceDelegatesMap == null )
						propertyPersistenceDelegatesMap = new HashMap<>();

					if( delegate != null ) {
						if( !(delegate instanceof PersistenceDelegate) )
							throwPropDescException( desc.getName(),
								"persistenceDelegate",
								"is not an instance of java.beans.PersistenceDelegate." );
						propertyPersistenceDelegatesMap.put( type, (PersistenceDelegate) delegate );
					}
					if( extraDelegates != null ) {
						if( !(extraDelegates instanceof Object[]) )
							throwPropDescException( desc.getName(),
								"extraPersistenceDelegates",
								"is not an Object[]." );

						Object[] extraArray = (Object[]) extraDelegates;
						if( extraArray.length % 2 != 0 )
							throwPropDescException( desc.getName(),
								"extraPersistenceDelegates",
								"size of Object[] is not a multiple of two." );

						for( int j = 0; j < extraArray.length; j += 2 ) {
							if( !(extraArray[j] instanceof Class<?>) )
								throwPropDescException( desc.getName(),
									"extraPersistenceDelegates",
									"Object[" + j + "] is not an instance of java.lang.Class." );
							if( !(extraArray[j+1] instanceof PersistenceDelegate) )
								throwPropDescException( desc.getName(),
									"extraPersistenceDelegates",
									"Object[" + (j+1) + "] is not an instance of java.beans.PersistenceDelegate." );

							propertyPersistenceDelegatesMap.put( (Class<?>) extraArray[j], (PersistenceDelegate) extraArray[j+1] );
						}
					}
				}
			}
			if( propertyPersistenceDelegatesMap == null )
				propertyPersistenceDelegatesMap = EMPTY_MAP2;
		}
		return propertyPersistenceDelegatesMap;
	}

	private void throwPropDescException( String propName, String attrName, String message ) {
		BeanDescriptor beanDesc = getBeanDescriptor();
		String className = (beanDesc != null) ? beanDesc.getBeanClass().getName() : "";
		throw new IllegalArgumentException( className + "." + propName
			+ ": Property descriptor attribute value \"" + attrName + "\" "
			+ message );
	}
}
