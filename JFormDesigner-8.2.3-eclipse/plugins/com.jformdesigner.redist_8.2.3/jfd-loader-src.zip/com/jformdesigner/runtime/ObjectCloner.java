/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;

/**
 * @author Karl Tauber
 */
public class ObjectCloner
{
	public static Object cloneObject( Object o ) {
		if( o == null )
			return null;

		Class<?> cls = o.getClass();
		if( isImmutable( cls ) )
			return o;

		if( cls.isArray() ) {
			Class<?> componentType = cls.getComponentType();
			int arrayLength = Array.getLength( o );
			Object newArray = Array.newInstance( componentType, arrayLength );
			if( isImmutable( componentType ) || componentType.isPrimitive() )
				System.arraycopy( o, 0, newArray, 0, arrayLength );
			else {
				for( int i = 0; i < arrayLength; i++ )
					Array.set( newArray, i, cloneObject( Array.get( o, i ) ) );
			}
			return newArray;
		}

		for( UIObjectCloner uiObjectCloner : uiObjectCloners ) {
			Object result = uiObjectCloner.cloneObject( o );
			if( result != null )
				return result;
		}

		return o;
	}

	public static boolean isImmutable( Class<?> cls ) {
		if( cls == Boolean.class || // java.lang
			cls == Byte.class ||
			cls == Character.class ||
			cls == Double.class ||
			cls == Float.class ||
			cls == Integer.class ||
			cls == Long.class ||
			cls == Short.class ||
			cls == String.class ||
			cls == Void.class )
		  return true;

		for( UIObjectCloner uiObjectCloner : uiObjectCloners ) {
			if( uiObjectCloner.isImmutable( cls ) )
				return true;
		}

		return false;
	}

	//---- UI toolkit extensions ----------------------------------------------

	private static UIObjectCloner[] uiObjectCloners = new UIObjectCloner[0];

	static {
		try {
			// using reflection because class is in another project
			Class<?> cls = Class.forName( "com.jformdesigner.runtime.SwingObjectCloner" );
			Constructor<?> constructor = cls.getDeclaredConstructor();
			addUIObjectCloner( (UIObjectCloner) constructor.newInstance() );
		} catch( Exception ex ) {
			throw new RuntimeException( "new com.jformdesigner.runtime.SwingObjectCloner() failed", ex );
		}
	}

	/**
	 * @since 6.0
	 */
	public static void addUIObjectCloner( UIObjectCloner uiObjectCloner ) {
		UIObjectCloner[] newUIObjectCloners = new UIObjectCloner[uiObjectCloners.length + 1];
		System.arraycopy( uiObjectCloners, 0, newUIObjectCloners, 0, uiObjectCloners.length );
		newUIObjectCloners[uiObjectCloners.length] = uiObjectCloner;
		uiObjectCloners = newUIObjectCloners;
	}

	//---- interface UIObjectCloner -------------------------------------------

	/**
	 * @since 6.0
	 */
	public interface UIObjectCloner {
		public Object cloneObject( Object o );
		public boolean isImmutable( Class<?> cls );
	}
}
